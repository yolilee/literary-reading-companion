# Literary Reading Companion

**Turn a photograph of a novel into a thoughtful, bilingual reading session.**

A reusable, open-source reading workflow for English learners moving from **B2 to C1**. Instead of giving you an unsorted vocabulary dump, it helps you understand the scene, think about the literature, and learn the words **in the order you encountered them**.

> **Photo of two book pages → Story recap → One meaningful question → Ordered vocabulary + visual references**

**Languages:** English literary text; Simplified Chinese explanations and translations.  
**Designed for:** readers of English-language fiction, especially literary fiction and mythology retellings.  
**Core file:** [`SKILL.md`](SKILL.md)

## What makes it different?

| Feature | What you get |
| --- | --- |
| Context first | A concise, spoiler-conscious recap of only the photographed pages. |
| Literature, not just definitions | **One** open-ended question about character, choice, relationships, or themes. |
| True reading order | Vocabulary follows **left page top-to-bottom, then right page top-to-bottom**. Never alphabetical. |
| B2 → C1 coverage | Common-but-challenging literary words are included, not overlooked. |
| Complete word entries | **American IPA**, approximate **CEFR**, contextual **Chinese meaning**, original **English example**, and **Chinese translation**. |
| Images where useful | Relevant real reference images placed near concrete words, if the chat environment supports image search. |
| Careful reading | No invented words when photos are blurred or covered; no spoilers beyond the pages supplied. |

## Preview: what a reading session looks like

The following is an **illustrative demonstration** inspired by vocabulary and themes encountered while reading Madeline Miller's *Circe*. It is **not a transcription of any two pages**, and the sample words are not claimed to appear together in this order. In actual use, the words are extracted from the photograph in their exact order.

**You upload:** a clear photograph of two facing pages of a novel.

**You receive:**

### 1. 📖 Story recap / 本页概要

> Circe reflects on the difference between gods and mortals. Human lives are short, but love, craftsmanship, and memory may leave a lasting mark.
>
> 瑟西开始思考神与凡人的不同。凡人的生命虽然短暂，但爱、创造与记忆却可能留下长久的痕迹。

### 2. 💭 One discussion question / 深度讨论

> **Can a brief but meaningful relationship be more valuable than an eternal one without change?**
>
> 一段短暂却深刻的关系，是否可能比一段永恒但缺乏变化的关系更有价值？

### 3. 📚 Vocabulary in page order / 按原文顺序学习生词

**LEFT PAGE / 左页**

**01 · reprieve** `/rɪˈpriːv/` · **C1**  
**中文：** 暂缓惩罚；短暂喘息  
**Example:** The rain brought a brief reprieve from the heat.  
**翻译：** 这场雨让酷热暂时得到缓解。

**02 · scoff** `/skɑːf/` · **C1**  
**中文：** 嘲笑；嗤之以鼻  
**Example:** She scoffed at the idea that she should give up.  
**翻译：** 对于她应该放弃的想法，她嗤之以鼻。

**RIGHT PAGE / 右页**

**03 · flare** `/fler/` · **B2–C1**  
**中文：** 突然燃起；（情绪）骤然爆发  
**Example:** Anger flared in his eyes before he turned away.  
**翻译：** 他转身前，眼中突然闪过怒意。

**04 · flesh** `/fleʃ/` · **B2**  
**中文：** 肉；肉体。注意与 *flash*（闪光）区分。  
**Example:** The creature's flesh bore old scars.  
**翻译：** 那生物的皮肉上留着旧伤疤。

**Visual placement example:** After a concrete word such as *loom*, *brazier*, or *prow*, the assistant places a matching reference image **right next to that word** when image retrieval is supported. This README intentionally does not use unlicensed or invented image URLs.

See the [extended sample response](examples/sample-output.md).

## Quick start

### ChatGPT: use the instructions in a conversation

1. Open [`SKILL.md`](SKILL.md).
2. Copy its contents into a new ChatGPT conversation or the instructions of a custom GPT.
3. Upload one or more readable photographs of your book pages.
4. Ask the assistant to follow the reading-companion workflow.

**Copyable prompt:**

```text
Follow the Literary Reading Companion instructions for these photographed pages.
First give me a short Chinese recap, then exactly one thoughtful discussion
question, then all useful B2–C1 vocabulary in the book's reading order:
left page top-to-bottom, then right page top-to-bottom.
Include US IPA, approximate CEFR, contextual Chinese meanings,
original English examples with Chinese translations, and relevant
real images next to concrete words when available.
Do not guess words that are obscured in the photo.
```

### Skill-compatible environments

Use [`SKILL.md`](SKILL.md) according to the skill installation mechanism of your agent or editor. **A GitHub repository does not automatically become an `@`-mentionable ChatGPT Skill.** Whether you can install or invoke it by name depends on the platform and its current features.

## Output rules at a glance

- Recap **first**, discussion question **second**, vocabulary **third**.
- **One** discussion question, not a quiz or a barrage of prompts.
- **Left page → right page**, each from top to bottom.
- Prioritize comprehensive B2/C1 coverage. Don't miss words like *reprieve*, *scoff*, *flare*, *waver*, *hoarse*, or *wrench*.
- Don't pad the list with basic vocabulary just to make it long.
- Images are useful for concrete objects, not decorative filler.
- If the user asks about only one word, answer that word directly.
- Do not quote extensive copyrighted book passages.

## Repository structure

```text
literary-reading-companion/
├── README.md                  # English first, 中文说明 below
├── SKILL.md                   # Reusable agent instructions
├── examples/
│   └── sample-output.md      # Longer example response
└── LICENSE                   # MIT
```

## License and responsible use

Released under the [MIT License](LICENSE). The instructions and teaching examples are original. Do not publish copyrighted page photographs without permission. CEFR word levels are approximate teaching labels, not official ratings.

---

# 中文说明｜文学英语阅读助手

**把一张英文小说的照片，变成一场有深度、有结构的双语阅读学习。**

这个开源 Skill 专为希望从 **B2 进阶到 C1** 的英文小说读者设计。它不只是提取单词，而是把**理解故事、讨论文学、学习词汇**结合在一起。

> **拍摄两页小说 → 中文剧情概述 → 一个深度讨论问题 → 按原文顺序整理生词和图片**

## 它有什么特别之处？

| 功能 | 具体效果 |
| --- | --- |
| 先理解剧情 | 用简洁中文概括照片中的内容，不提前剧透。 |
| 深度阅读 | 每次提出**一个**与人物、选择、情感或主题相关的问题。 |
| 严格按原书顺序 | **先左页从上到下，再右页从上到下**，不按字母或难度重新排序。 |
| 针对 B2–C1 | 不遗漏 *reprieve*、*scoff*、*flare* 等文学阅读中常见但容易卡住的词。 |
| 完整词汇讲解 | **美式音标、CEFR 难度、中文释义、原创英文例句、例句中文翻译**。 |
| 图像辅助记忆 | 对 *loom*（织布机）、*brazier*（火盆）等具体词汇，尽量就近插入真实参考图片。 |
| 尊重原文 | 遇到被手指挡住、模糊的文字会说明，不会编造内容。 |

## 效果示例

上方英文部分已经展示了一套完整的**模拟阅读输出**，包含剧情概述、一个讨论问题，以及 `reprieve`、`scoff`、`flare`、`flesh` 的音标、难度和双语例句。

这组词来自我们阅读 *Circe* 时关注的词汇类型，但**不是对某一组书页的逐字转录**。真正使用时，单词会严格遵循你上传照片中的先后顺序。

## 如何使用？

1. 打开 [`SKILL.md`](SKILL.md)，复制里面的指令。
2. 粘贴到新的 ChatGPT 对话中，或者自定义 GPT 的 Instructions（指令）中。
3. 上传英文小说页面的照片。
4. 让 AI 按照 Skill 的规则生成阅读内容。

**可直接复制的中文指令：**

```text
请按照 Literary Reading Companion 的规则分析这张小说照片。
先用中文概括这两页，再提出一个值得深入讨论的问题。
最后严格按照左页从上到下、右页从上到下的顺序，
完整提取 B2–C1 生词和重要固定搭配。
每个词提供美式音标、CEFR、中文释义、原创英文例句和中文翻译。
适合用图片记忆的具体词汇，请在对应词条旁插入真实参考图片。
看不清的单词不要猜测，也不要提前剧透。
```

**关于 `@Skill`：** 将文件放到 GitHub 不会自动让它出现在 ChatGPT 的 `@` 列表中。是否支持安装、通过名称调用，需要看具体平台。GitHub 仓库首先提供的是**可复用的指令文件与公开文档**。

## 项目文件

- [`SKILL.md`](SKILL.md)：阅读助手的完整行为规则。
- [`examples/sample-output.md`](examples/sample-output.md)：更完整的输出示例。
- [`LICENSE`](LICENSE)：MIT 开源协议。

欢迎学习者和开发者使用、改进、分享。请勿在未经授权的情况下将受版权保护的小说页面照片公开上传到仓库。
